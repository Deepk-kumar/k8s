# Kubernetes CronJobs: Real-world Use Cases and Examples

## Real-world Use Cases for Kubernetes CronJobs

### 1. Data Backups
Schedule regular backups of critical data to ensure data integrity and disaster recovery preparedness.

### 2. Data Syncing
Periodically synchronize data between different systems or databases to maintain consistency and up-to-date information.

### 3. Periodic Maintenance
Automate routine maintenance tasks such as log rotation, database cleanup, or temporary file deletion to optimize system performance and resource utilization.

---

## Types of Kubernetes CronJobs

### 1. Basic CronJobs
- Simple cron-based scheduling of recurring tasks.

#### Example Manifest:
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: basic-cronjob
spec:
  schedule: "*/1 * * * *"
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: basic-cronjob
            image: busybox
            args:
            - /bin/sh
            - -c
            - date; echo Hello from the Kubernetes cluster
          restartPolicy: OnFailure
```

#### Apply the changes using the command:
```bash
kubectl apply -f basic-cron-job.yaml
```

#### Output:
```bash
$ kubectl get pod,job,cronjob
NAME                               READY   STATUS      RESTARTS   AGE
pod/basic-cronjob-28558276-xqhq8   0/1     Completed   0          111s
pod/basic-cronjob-28558277-6fpxr   0/1     Completed   0          51s

NAME                               COMPLETIONS   DURATION   AGE
job.batch/basic-cronjob-28558276   1/1           4s         111s
job.batch/basic-cronjob-28558277   1/1           4s         51s

NAME                          SCHEDULE      SUSPEND   ACTIVE   LAST SCHEDULE   AGE
cronjob.batch/basic-cronjob   */1 * * * *   False     0        52s             2m15s
```

### 2. Concurrency Policy CronJobs
- Specify how to handle concurrent executions of a CronJob, allowing for fine-grained control over task execution.

#### Allowed values for `concurrencyPolicy`:
- **Allow (default):** The CronJob allows concurrently running Jobs.
- **Forbid:** The CronJob does not allow concurrent runs; skips the new Job if the previous one hasn't finished.
- **Replace:** Replaces the currently running Job with a new Job run.

#### Example Manifest:
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: concurrency-cronjob
spec:
  schedule: "*/1 * * * *"
  concurrencyPolicy: Forbid
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: concurrency-cronjob
            image: busybox
            args:
            - /bin/sh
            - -c
            - sleep 70; echo Completed
          restartPolicy: OnFailure
```

#### Apply the changes using the command:
```bash
kubectl apply -f concurrency-cronjob.yaml
```

#### Output:
```bash
$ kubectl get pod,job,cronjob
NAME                                     READY   STATUS      RESTARTS   AGE
pod/concurrency-cronjob-28558287-pv2tr   0/1     Completed   0          82s
pod/concurrency-cronjob-28558288-29sq2   1/1     Running     0          9s

NAME                                     COMPLETIONS   DURATION   AGE
job.batch/concurrency-cronjob-28558287   1/1           73s        82s
job.batch/concurrency-cronjob-28558288   0/1           9s         9s

NAME                                SCHEDULE      SUSPEND   ACTIVE   LAST SCHEDULE   AGE
cronjob.batch/concurrency-cronjob   */1 * * * *   False     1        22s             119s
```

### 3. Job History Limits CronJobs
- Control the number of successful and failed Job completions retained by a CronJob, managing resource usage and storage requirements.

#### Example Manifest:
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: history-limit-cronjob
spec:
  schedule: "*/1 * * * *"
  successfulJobsHistoryLimit: 2
  failedJobsHistoryLimit: 1
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: history-limit-cronjob
            image: busybox
            args:
            - /bin/sh
            - -c
            - date; echo Job history limit example
          restartPolicy: OnFailure
```

#### Apply the changes using the command:
```bash
kubectl apply -f job-history-limit-cronjob.yaml
```

#### Output:
```bash
$ kubectl get pod,job,cronjob
NAME                                       READY   STATUS      RESTARTS   AGE
pod/history-limit-cronjob-28558295-qtdz6   0/1     Completed   0          71s
pod/history-limit-cronjob-28558296-774lw   0/1     Completed   0          11s

NAME                                       COMPLETIONS   DURATION   AGE
job.batch/history-limit-cronjob-28558295   1/1           4s         71s
job.batch/history-limit-cronjob-28558296   1/1           4s         11s

NAME                                  SCHEDULE      SUSPEND   ACTIVE   LAST SCHEDULE   AGE
cronjob.batch/history-limit-cronjob   */1 * * * *   False     0        11s             3m9s
```

---

## Summary
Kubernetes CronJobs provide powerful scheduling capabilities for a wide range of use cases such as data backups, periodic maintenance, and data syncing. By leveraging features like `concurrencyPolicy` and job history limits, you can fine-tune the behavior of your CronJobs to suit specific operational needs.
